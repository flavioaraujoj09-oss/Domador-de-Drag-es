# Domador de Dragões

Jogo RPG idle de treinar domador e dragão, com batalhas, exércitos, vestimentas e uma saga.

Este projeto roda **fora do Claude**, então o progresso é salvo no `localStorage`
do seu próprio navegador — é permanente de verdade, independente de qualquer
sessão de chat.

> Aviso: o Salão da Fama (ranking) usa o mesmo `localStorage`, então nesta
> versão local ele só mostra dados salvos neste navegador/computador. Pra
> virar um ranking global de verdade entre jogadores diferentes, é preciso
> um backend (ex: Firebase, Supabase) — não incluído aqui por padrão.

## 1. Rodar localmente

Pré-requisito: [Node.js](https://nodejs.org) instalado (versão 18+).

```bash
npm install
npm run dev
```

Abra o endereço que aparecer no terminal (algo como `http://localhost:5173`).

## 2. Colocar num repositório no GitHub

Se ainda não tem o Git configurado, instale em https://git-scm.com e crie
uma conta em https://github.com.

Dentro da pasta do projeto:

```bash
git init
git add .
git commit -m "Primeiro commit: Domador de Dragões"
```

Agora crie um repositório vazio no GitHub (botão "New repository", sem
adicionar README/gitignore pelo site). Depois:

```bash
git remote add origin https://github.com/SEU_USUARIO/NOME_DO_REPOSITORIO.git
git branch -M main
git push -u origin main
```

Pronto — o código está no GitHub e pode ser compartilhado por lá.

## 3. Publicar online para jogar pelo link (recomendado: Vercel)

1. Crie uma conta grátis em https://vercel.com (dá pra entrar direto com GitHub).
2. Clique em "Add New Project" e selecione o repositório que você acabou de subir.
3. Deixe as configurações padrão (o Vercel detecta Vite automaticamente) e clique em "Deploy".
4. Em alguns segundos você recebe um link público (tipo `seu-projeto.vercel.app`) para compartilhar com qualquer pessoa.

Alternativa igualmente simples: [Netlify](https://netlify.com), mesmo fluxo.

### Se preferir GitHub Pages
1. Rode `npm run build` (gera a pasta `dist`).
2. No arquivo `vite.config.js`, troque `base: "/"` por `base: "/NOME_DO_REPOSITORIO/"`.
3. Publique o conteúdo de `dist` na branch `gh-pages` (pode usar a extensão/action `gh-pages` do npm ou o painel do GitHub em Settings → Pages).

## Personalizando o visual (artes do personagem e do dragão)

Por padrão o jogo desenha o personagem e o dragão em SVG (vetor). Se você
quiser usar artes de verdade (ex: geradas por IA no estilo anime/pintado),
veja `public/images/README.md` — é só colocar os arquivos PNG nos nomes
certos que o jogo passa a usá-los automaticamente, sem precisar mexer em
código.

## Estrutura do projeto

```
src/
  App.jsx        → todo o jogo (estado, telas, batalhas, loja)
  storage.js      → salva o progresso no localStorage do navegador
  main.jsx        → ponto de entrada React
  index.css       → Tailwind
```

## Observação sobre o save

Como o jogo agora salva no `localStorage` do navegador (e não mais no
armazenamento interno do Claude), o progresso:

- **Persiste** entre fechamentos de aba, reinícios do computador e
  atualizações do site.
- **Não** é sincronizado entre navegadores ou dispositivos diferentes — é
  local por navegador. Se quiser sincronizar entre celular e computador,
  o próximo passo seria trocar `storage.js` por uma chamada a um backend
  real (Firebase Firestore é o mais simples de configurar para isso).
