# Como colocar suas próprias artes no jogo

O jogo tenta carregar uma imagem de verdade primeiro; se o arquivo não
existir, ele automaticamente desenha a versão em SVG (o visual atual) no
lugar — então você pode adicionar as imagens aos poucos, sem quebrar nada.

## Personagem

Coloque um arquivo PNG (fundo transparente funciona melhor) para cada classe em:

```
public/images/characters/guerreiro.png
public/images/characters/cacador.png
public/images/characters/arcanista.png
```

## Dragão

O dragão tem 5 linhagens de cor × 10 estágios de evolução = 50 imagens no
total (opcional — pode preencher só as que quiser, as que faltarem usam o SVG).

Pastas já criadas:
```
public/images/dragons/sangue/
public/images/dragons/abissal/
public/images/dragons/veneno/
public/images/dragons/gelido/
public/images/dragons/cinzas/
```

Dentro de cada uma, os nomes de arquivo esperados são:
```
egg.png       (Ovo Adormecido)
cracked.png   (Ovo Rachado)
stage1.png    (Filhote Recém-Nascido)
stage2.png    (Filhote das Sombras)
stage3.png    (Jovem Predador)
stage4.png    (Fera Sombria)
stage5.png    (Predador Ancião)
stage6.png     (Terror Ancestral)
stage7.png    (Flagelo das Trevas)
stage8.png    (Wyrm Lendário)
```

## Gerando as artes

Use as duas imagens de referência que você já tem (dragão vermelho estilo
anime/pintado e o cavaleiro) num gerador de imagem por IA (Midjourney,
ChatGPT/DALL-E, Leonardo.ai, Bing Image Creator, etc.), pedindo variações no
mesmo estilo para cada estágio/cor. Dica de prompt:

> "Anime/painterly fantasy dragon, [cor: red/purple/green/cyan/orange]
> scales, [estágio: hatchling / young / adult / ancient / legendary],
> dynamic pose, blue sky background, key art style, high detail"

Depois de gerar, salve como PNG com fundo transparente (ou recorte) e jogue
na pasta certa com o nome exato acima.
