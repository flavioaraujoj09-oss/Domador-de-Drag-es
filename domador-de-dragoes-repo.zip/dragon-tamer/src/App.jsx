import React, { useState, useEffect, useRef, useCallback } from "react";
import { Sword, Shield, Flame, Zap, Coins, Star, Skull, Swords, ShieldAlert, ChevronRight, RotateCcw, Home, Briefcase, Trophy, Clock, User, BookOpen, Lock, Save, Users, MousePointerClick } from "lucide-react";
import "./storage.js"; // liga window.storage a um localStorage real do navegador

/* =========================================================
   CONFIG
   ========================================================= */
const STORAGE_KEY = "dragon-tamer-save-v12";
// Pasta onde ficam as artes reais (opcionais). Se a imagem não existir, o
// jogo usa automaticamente o desenho SVG como visual de reserva — nada quebra.
const IMG_BASE = "/images";
const PLAYER_ID_KEY = "dragon-tamer-player-id";
const LEADERBOARD_PREFIX = "hall-of-fame:";
const MAX_OFFLINE_SECONDS = 4 * 60 * 60;

const DRAGON_COLORS = [
  { id: "sangue", name: "Escama de Sangue", grad: "from-red-950 via-red-800 to-rose-950", glow: "shadow-red-900/70", ring: "ring-red-700", hex: "#7f1d1d", light: "#ef4444", dark: "#2b0a0a", eye: "#fde047" },
  { id: "abissal", name: "Escama Abissal", grad: "from-slate-950 via-purple-950 to-black", glow: "shadow-purple-900/70", ring: "ring-purple-800", hex: "#3b0764", light: "#a855f7", dark: "#150526", eye: "#e9d5ff" },
  { id: "veneno", name: "Escama Venenosa", grad: "from-emerald-950 via-lime-900 to-green-950", glow: "shadow-lime-900/70", ring: "ring-lime-700", hex: "#14532d", light: "#4ade80", dark: "#052e16", eye: "#fef08a" },
  { id: "gelido", name: "Escama Gélida", grad: "from-cyan-950 via-slate-800 to-blue-950", glow: "shadow-cyan-900/70", ring: "ring-cyan-700", hex: "#164e63", light: "#22d3ee", dark: "#082f36", eye: "#e0f2fe" },
  { id: "cinzas", name: "Escama de Cinzas", grad: "from-neutral-900 via-orange-950 to-neutral-950", glow: "shadow-orange-900/70", ring: "ring-orange-800", hex: "#431407", light: "#fb923c", dark: "#1c0a03", eye: "#fde68a" },
];

const CLASSES = [
  { id: "guerreiro", name: "Guerreiro", icon: "🗡️", desc: "Mais força bruta ao lutar", statBonus: { forca: 2 } },
  { id: "cacador", name: "Caçador", icon: "🏹", desc: "Mais precisão e velocidade", statBonus: { velocidade: 2 } },
  { id: "arcanista", name: "Arcanista", icon: "🔮", desc: "Fortalece a defesa mística", statBonus: { defesa: 2 } },
];

// Evolução: o ovo racha logo no início e o dragão evolui junto do domador —
// a cada 2 níveis do personagem, o dragão sobe 1 nível automaticamente.
const EVOLUTION_STAGES = [
  { min: 1, max: 1, name: "Ovo Adormecido", icon: "🥚", scale: 0.5, kind: "egg", imgKey: "egg" },
  { min: 2, max: 2, name: "Ovo Rachado", icon: "🥚", scale: 0.58, kind: "cracked", imgKey: "cracked" },
  { min: 3, max: 5, name: "Filhote Recém-Nascido", icon: "🐣", scale: 0.68, kind: "dragon", wingTier: 1, imgKey: "stage1" },
  { min: 6, max: 8, name: "Filhote das Sombras", icon: "🐲", scale: 0.78, kind: "dragon", wingTier: 1, imgKey: "stage2" },
  { min: 9, max: 11, name: "Jovem Predador", icon: "🐲", scale: 0.88, kind: "dragon", wingTier: 2, imgKey: "stage3" },
  { min: 12, max: 14, name: "Fera Sombria", icon: "🐉", scale: 0.98, kind: "dragon", wingTier: 2, imgKey: "stage4" },
  { min: 15, max: 17, name: "Predador Ancião", icon: "🐉", scale: 1.08, kind: "dragon", wingTier: 3, imgKey: "stage5" },
  { min: 18, max: 20, name: "Terror Ancestral", icon: "🐉", scale: 1.18, kind: "dragon", wingTier: 3, imgKey: "stage6" },
  { min: 21, max: 25, name: "Flagelo das Trevas", icon: "🐉", scale: 1.28, kind: "dragon", wingTier: 4, imgKey: "stage7" },
  { min: 26, max: 9999, name: "Wyrm Lendário", icon: "🐲", scale: 1.4, kind: "dragon", wingTier: 5, imgKey: "stage8" },
];

const WEAPONS = [
  { id: "adaga", name: "Adaga Amaldiçoada", icon: "🗡️", baseCost: 40, clickBonus: 1 },
  { id: "espada", name: "Espada Rúnica", icon: "⚔️", baseCost: 260, clickBonus: 3 },
  { id: "machado", name: "Machado Carrasco", icon: "🪓", baseCost: 1300, clickBonus: 7 },
  { id: "lanca_rubi", name: "Lança do Dragão Caído", icon: "🔱", baseCost: 7000, clickBonus: 18 },
  { id: "foice", name: "Foice do Ceifador", icon: "⚜️", baseCost: 32000, clickBonus: 50 },
  { id: "martelo_titan", name: "Martelo do Titã Caído", icon: "🔨", baseCost: 140000, clickBonus: 130 },
  { id: "chicote_alma", name: "Chicote Devora-Almas", icon: "⛓️", baseCost: 600000, clickBonus: 320 },
  { id: "cetro_negro", name: "Cetro Negro do Abismo", icon: "🖤", baseCost: 2500000, clickBonus: 780 },
];

const ARMORS = [
  { id: "couro", name: "Couro de Necrofauna", icon: "🥋", baseCost: 65, idlePercent: 0.03 },
  { id: "cota", name: "Cota Sombria", icon: "🛡️", baseCost: 420, idlePercent: 0.06 },
  { id: "placas", name: "Placas do Carrasco", icon: "🏰", baseCost: 2100, idlePercent: 0.11 },
  { id: "escama", name: "Escama de Wyrm Ancião", icon: "🐉", baseCost: 10000, idlePercent: 0.2 },
  { id: "abissal", name: "Manto Abissal", icon: "🌑", baseCost: 42000, idlePercent: 0.35 },
  { id: "carapaca_titan", name: "Carapaça do Titã", icon: "🦾", baseCost: 180000, idlePercent: 0.55 },
  { id: "vestes_eternas", name: "Vestes Eternas", icon: "🌌", baseCost: 750000, idlePercent: 0.8 },
  { id: "nucleo_caos", name: "Núcleo do Caos", icon: "🔮", baseCost: 3200000, idlePercent: 1.15 },
];

const ABILITIES = [
  { id: "sopro", name: "Sopro Necrótico", icon: "🔥", baseCost: 200, stat: "forca", gain: 1 },
  { id: "voo", name: "Voo das Trevas", icon: "🌬️", baseCost: 550, stat: "velocidade", gain: 1 },
  { id: "escamas", name: "Escamas Reforçadas", icon: "🛡️", baseCost: 1300, stat: "defesa", gain: 2 },
  { id: "rugido", name: "Rugido do Abismo", icon: "📣", baseCost: 4000, stat: "forca", gain: 4 },
  { id: "tempestade", name: "Tempestade Arcana", icon: "⚡", baseCost: 11000, stat: "velocidade", gain: 5 },
  { id: "carapaca", name: "Carapaça Espectral", icon: "💀", baseCost: 24000, stat: "defesa", gain: 7 },
  { id: "vida", name: "Vitalidade Sombria", icon: "❤️‍🔥", baseCost: 8000, stat: "vida", gain: 12 },
  { id: "garras", name: "Garras Ancestrais", icon: "🦇", baseCost: 55000, stat: "forca", gain: 9 },
  { id: "instinto", name: "Instinto Predador", icon: "👁️", baseCost: 95000, stat: "velocidade", gain: 10 },
  { id: "couraça", name: "Couraça do Abismo", icon: "🪨", baseCost: 160000, stat: "defesa", gain: 14 },
  { id: "furia", name: "Fúria Primordial", icon: "🌋", baseCost: 400000, stat: "forca", gain: 20 },
];

// Trabalhos: o domador se ausenta um tempo real e volta com recompensa
const JOBS = [
  { id: "caca", name: "Caçar suprimentos na floresta", icon: "🏹", durationSec: 30, gold: 40, xp: 3 },
  { id: "escolta", name: "Escoltar caravana", icon: "🐎", durationSec: 120, gold: 200, xp: 10 },
  { id: "mercenario", name: "Trabalho de mercenário", icon: "🗡️", durationSec: 300, gold: 550, xp: 22 },
  { id: "expedicao", name: "Expedição às ruínas antigas", icon: "🏛️", durationSec: 900, gold: 1900, xp: 60 },
  { id: "contrato", name: "Contrato da Guilda Negra", icon: "📜", durationSec: 1800, gold: 4800, xp: 140 },
];

// Vestimentas do personagem — puramente visual, monta o "sprite" do domador
const CLOTHING = {
  helmet: [
    { id: "capuz", name: "Capuz Surrado", icon: "🎭", baseCost: 45 },
    { id: "elmo_ferro", name: "Elmo de Ferro Negro", icon: "⛑️", baseCost: 380 },
    { id: "coroa_cranio", name: "Coroa de Crânio", icon: "👑", baseCost: 3200 },
  ],
  cloak: [
    { id: "manto_viajante", name: "Manto de Viajante", icon: "🧣", baseCost: 60 },
    { id: "capa_sombras", name: "Capa das Sombras", icon: "🥷", baseCost: 500 },
    { id: "manto_dracônico", name: "Manto Dracônico", icon: "🦇", baseCost: 4200 },
  ],
  weapon_visual: [
    { id: "cajado", name: "Cajado Rúnico", icon: "🪄", baseCost: 50 },
    { id: "espada_visual", name: "Espada à Cintura", icon: "🗡️", baseCost: 420 },
    { id: "tridente", name: "Tridente Sombrio", icon: "🔱", baseCost: 3600 },
  ],
};
const CLOTHING_SLOT_LABELS = { helmet: "Elmo", cloak: "Manto", weapon_visual: "Arma à mostra" };

// A saga: capítulos ligados a cada dificuldade de monstro
const CHAPTERS = [
  { tier: 1, title: "Capítulo I — O Chamado", text: "Lobos espectrais rondam a aldeia. A Ordem dos Domadores precisa saber se você e seu dragão estão prontos para o juramento." },
  { tier: 2, title: "Capítulo II — Sangue nos Pântanos", text: "Ogros corrompidos pela Legião das Escamas Negras destroem vilarejos inteiros. Seu primeiro teste de comando começa aqui." },
  { tier: 3, title: "Capítulo III — Sussurros do Vazio", text: "Criaturas do Vazio se infiltram no mundo através de fendas abertas pela Legião. Algo maior as está guiando." },
  { tier: 4, title: "Capítulo IV — Os Caídos", text: "Antigos cavaleiros da Ordem, corrompidos, agora servem ao inimigo. Derrotá-los é um fardo, não uma vitória." },
  { tier: 5, title: "Capítulo V — O Coração de Pedra", text: "Golens de obsidiana guardam as minas onde a Legião forja armaduras para seus dragões escravizados." },
  { tier: 6, title: "Capítulo VI — A Fenda Negra", text: "Uma hidra nascida da corrupção guarda a fenda que liga este mundo ao covil da Legião das Escamas Negras." },
  { tier: 7, title: "Capítulo VII — Pacto de Ferro", text: "Um general demoníaco da Legião oferece um pacto. Recusar significa guerra aberta — e é isso que você quer." },
  { tier: 8, title: "Capítulo VIII — A Alcateia Eterna", text: "Fenrir das Cinzas lidera os últimos batalhões antes das portas do covil ancestral. Seu exército de dragões começa a se formar." },
  { tier: 9, title: "Capítulo IX — O Wyrm Corrompido", text: "Um dragão irmão, corrompido há eras pela Legião, ataca. Vencê-lo é libertar uma alma, não apenas uma batalha." },
  { tier: 10, title: "Capítulo Final — O Devorador de Mundos", text: "A entidade que comanda a Legião das Escamas Negras desperta. Lidere seu exército de dragões domados nesta batalha final." },
];
const DECORATIONS = [
  { id: "fogueira", name: "Fogueira Ritual", icon: "🔥", baseCost: 100, idleBonus: 0.03 },
  { id: "ossario", name: "Ossário Decorativo", icon: "🦴", baseCost: 500, idleBonus: 0.05 },
  { id: "altar", name: "Altar Sombrio", icon: "🕯️", baseCost: 2200, idleBonus: 0.08 },
  { id: "trono", name: "Trono de Pedra Negra", icon: "🪑", baseCost: 9000, idleBonus: 0.12 },
];

// Monstros — curva de dificuldade bem mais íngreme
const MONSTERS = [
  { tier: 1, name: "Lobo Espectral", icon: "🐺", hp: 55, atk: 9, def: 3, goldMin: 50, goldMax: 80 },
  { tier: 2, name: "Ogro Podre", icon: "👹", hp: 130, atk: 16, def: 6, goldMin: 120, goldMax: 190 },
  { tier: 3, name: "Aranha do Vazio", icon: "🕷️", hp: 260, atk: 25, def: 10, goldMin: 260, goldMax: 380 },
  { tier: 4, name: "Cavaleiro Caído", icon: "💀", hp: 460, atk: 38, def: 16, goldMin: 480, goldMax: 700 },
  { tier: 5, name: "Golem de Obsidiana", icon: "🗿", hp: 780, atk: 52, def: 30, goldMin: 850, goldMax: 1200 },
  { tier: 6, name: "Hidra Negra", icon: "🐍", hp: 1250, atk: 72, def: 38, goldMin: 1500, goldMax: 2100 },
  { tier: 7, name: "Demônio de Ferro", icon: "😈", hp: 1900, atk: 95, def: 52, goldMin: 2600, goldMax: 3600 },
  { tier: 8, name: "Fenrir das Cinzas", icon: "🐺", hp: 2900, atk: 125, def: 68, goldMin: 4500, goldMax: 6200 },
  { tier: 9, name: "Wyrm Corrompido", icon: "🐉", hp: 4400, atk: 165, def: 90, goldMin: 8000, goldMax: 11000 },
  { tier: 10, name: "O Devorador de Mundos", icon: "👁️", hp: 6800, atk: 220, def: 120, goldMin: 15000, goldMax: 21000 },
];

// Batalhas de exército: seu dragão lidera aliados recrutados contra hordas em várias ondas
const ARMY_CAMPAIGNS = [
  {
    tier: 1,
    name: "Emboscada na Fronteira",
    waves: [
      { name: "Batedores Corrompidos", icon: "🐺", hp: 200, atk: 20, def: 8 },
      { name: "Arqueiros das Sombras", icon: "🏹", hp: 260, atk: 26, def: 10 },
      { name: "Capitão Renegado", icon: "🗡️", hp: 340, atk: 34, def: 14 },
    ],
    goldMin: 2000, goldMax: 2800,
  },
  {
    tier: 2,
    name: "Cerco ao Vale Negro",
    waves: [
      { name: "Legião de Ogros", icon: "👹", hp: 500, atk: 45, def: 20 },
      { name: "Golens de Guerra", icon: "🗿", hp: 650, atk: 55, def: 30 },
      { name: "General das Escamas", icon: "😈", hp: 850, atk: 70, def: 40 },
    ],
    goldMin: 6000, goldMax: 8500,
  },
  {
    tier: 3,
    name: "Queda do Bastião Ancestral",
    waves: [
      { name: "Guarda Dracônica Caída", icon: "🐍", hp: 1200, atk: 90, def: 55 },
      { name: "Hidras Gêmeas", icon: "🐉", hp: 1600, atk: 110, def: 70 },
      { name: "Comandante Wyrm", icon: "🐲", hp: 2200, atk: 140, def: 90 },
    ],
    goldMin: 16000, goldMax: 22000,
  },
];
const ALLY_BASE_COST = 800;
const ALLY_ATK_BONUS = 3;
const ALLY_DEF_BONUS = 2;
const AUTO_TRAINER_COST = 1500;

/* =========================================================
   HELPERS — curvas de progressão mais difíceis
   ========================================================= */
function costFor(baseCost, ownedCount) {
  return Math.round(baseCost * Math.pow(2.05, ownedCount));
}
// Curva de XP do JOGADOR (clique) — moderada
function xpToNext(level) {
  return Math.round(45 * Math.pow(1.5, level - 1));
}
// Curva de XP do DRAGÃO — muito mais dura: cada nível pede quase o dobro do anterior
function dragonXpToNext(level) {
  return Math.round(25 * Math.pow(1.72, level - 1));
}
function evolutionFor(level) {
  return EVOLUTION_STAGES.find((s) => level >= s.min && level <= s.max) || EVOLUTION_STAGES[EVOLUTION_STAGES.length - 1];
}
function dragonMaxHP(state) {
  return 50 + state.dragonLevel * 9 + state.dragonStats.vida * 3.5 + state.dragonStats.defesa * 1.5;
}
function playerClickPower(state) {
  const weaponBonus = WEAPONS.filter((w) => state.owned.weapons.includes(w.id)).reduce((s, w) => s + w.clickBonus, 0);
  return 1 + weaponBonus + Math.floor(state.playerLevel * 0.15);
}
function idleGoldPerSecond(state) {
  const armorMultiplier = ARMORS.filter((a) => state.owned.armors.includes(a.id)).reduce((s, a) => s + a.idlePercent, 0);
  const decoBonus = (state.owned.decorations || []).reduce((s, id) => {
    const d = DECORATIONS.find((x) => x.id === id);
    return s + (d ? d.idleBonus : 0);
  }, 0);
  const dragonPower = state.dragonStats.forca * 0.4 + state.dragonStats.velocidade * 0.25 + state.dragonLevel * 0.25;
  return dragonPower * (0.22 + armorMultiplier + decoBonus);
}
function uid() {
  return Math.random().toString(36).slice(2, 10) + Date.now().toString(36).slice(-4);
}
// A cada 2 níveis do domador, o dragão ganha 1 nível
function dragonLevelFromPlayer(playerLevel) {
  return 1 + Math.floor((playerLevel - 1) / 2);
}
function formatSavedAgo(now, savedAt) {
  const diffSec = Math.max(0, Math.floor((now - savedAt) / 1000));
  if (diffSec < 5) return "agora mesmo";
  if (diffSec < 60) return `há ${diffSec}s`;
  const diffMin = Math.floor(diffSec / 60);
  if (diffMin < 60) return `há ${diffMin} min`;
  const diffH = Math.floor(diffMin / 60);
  if (diffH < 24) return `há ${diffH}h`;
  const d = new Date(savedAt);
  return d.toLocaleDateString("pt-BR", { day: "2-digit", month: "2-digit" }) + " às " + d.toLocaleTimeString("pt-BR", { hour: "2-digit", minute: "2-digit" });
}

function defaultState() {
  return {
    setupDone: false,
    playerName: "",
    dragonName: "",
    classId: "guerreiro",
    colorId: "sangue",
    gold: 25,
    playerLevel: 1,
    playerXP: 0,
    dragonLevel: 1,
    dragonXP: 0,
    dragonStats: { forca: 1, defesa: 1, velocidade: 1, vida: 0 },
    owned: { weapons: [], armors: [], abilities: {}, decorations: [], clothing: [], autoTrainer: false },
    autoTrainOn: true,
    equipped: { helmet: null, cloak: null, weapon_visual: null },
    highestTierCleared: 0,
    highestArmyTierCleared: 0,
    armyAllies: 0,
    battlesWon: 0,
    battlesLost: 0,
    activeJob: null, // { id, startTime, endTime }
    lastSeen: Date.now(),
  };
}

/* =========================================================
   MAIN COMPONENT
   ========================================================= */
export default function DragonTamerGame() {
  const [state, setState] = useState(defaultState());
  const [loaded, setLoaded] = useState(false);
  const [floatingTexts, setFloatingTexts] = useState([]);
  const [tab, setTab] = useState("lar");
  const [offlineReport, setOfflineReport] = useState(null);
  const [screen, setScreen] = useState("loading");
  const [battle, setBattle] = useState(null);
  const [playerId, setPlayerId] = useState(null);
  const [leaderboard, setLeaderboard] = useState([]);
  const [leaderboardLoading, setLeaderboardLoading] = useState(false);
  const [now, setNow] = useState(Date.now());
  const [lastSavedAt, setLastSavedAt] = useState(null);
  const [saveStatus, setSaveStatus] = useState("idle"); // idle | saving | saved | error
  const saveTimer = useRef(null);
  const floatId = useRef(0);

  useEffect(() => {
    (async () => {
      try {
        const idResult = await window.storage.get(PLAYER_ID_KEY, false);
        if (idResult && idResult.value) {
          setPlayerId(idResult.value);
        } else {
          const newId = uid();
          await window.storage.set(PLAYER_ID_KEY, newId, false);
          setPlayerId(newId);
        }
      } catch (e) {
        setPlayerId(uid());
      }

      try {
        const result = await window.storage.get(STORAGE_KEY, false);
        if (result && result.value) {
          const saved = JSON.parse(result.value);
          const merged = { ...defaultState(), ...saved };
          merged.owned = { ...defaultState().owned, ...(saved.owned || {}) };
          merged.dragonStats = { ...defaultState().dragonStats, ...(saved.dragonStats || {}) };

          const elapsedSec = Math.min(MAX_OFFLINE_SECONDS, Math.max(0, Math.floor((Date.now() - (saved.lastSeen || Date.now())) / 1000)));
          const gps = idleGoldPerSecond(merged);
          const earned = Math.floor(gps * elapsedSec);
          if (earned > 0 && merged.setupDone) {
            merged.gold += earned;
            setOfflineReport({ seconds: elapsedSec, gold: earned });
          }
          merged.lastSeen = Date.now();
          setState(merged);
          if (saved.lastSavedAt) setLastSavedAt(saved.lastSavedAt);
          setScreen(merged.setupDone ? "game" : "setup");
        } else {
          setScreen("setup");
        }
      } catch (e) {
        setScreen("setup");
      } finally {
        setLoaded(true);
      }
    })();
  }, []);

  // clock tick (para trabalhos com contagem regressiva)
  useEffect(() => {
    const t = setInterval(() => setNow(Date.now()), 1000);
    return () => clearInterval(t);
  }, []);

  useEffect(() => {
    if (!loaded || screen !== "game") return;
    const interval = setInterval(() => {
      setState((prev) => ({ ...prev, gold: prev.gold + idleGoldPerSecond(prev) / 4 }));
    }, 250);
    return () => clearInterval(interval);
  }, [loaded, screen]);

  const persistNow = useCallback(async () => {
    setSaveStatus("saving");
    try {
      const savedAt = Date.now();
      await window.storage.set(STORAGE_KEY, JSON.stringify({ ...stateRef.current, lastSeen: savedAt, lastSavedAt: savedAt }), false);
      setLastSavedAt(savedAt);
      setSaveStatus("saved");
      setTimeout(() => setSaveStatus((s) => (s === "saved" ? "idle" : s)), 2000);
    } catch (e) {
      setSaveStatus("error");
    }
    if (playerId && stateRef.current.setupDone) {
      try {
        await window.storage.set(
          LEADERBOARD_PREFIX + playerId,
          JSON.stringify({
            playerName: stateRef.current.playerName,
            dragonName: stateRef.current.dragonName,
            dragonLevel: stateRef.current.dragonLevel,
            playerLevel: stateRef.current.playerLevel,
            colorId: stateRef.current.colorId,
            battlesWon: stateRef.current.battlesWon,
            highestTierCleared: stateRef.current.highestTierCleared,
            updatedAt: Date.now(),
          }),
          true
        );
      } catch (e) {}
    }
  }, [playerId]);

  const stateRef = useRef(state);
  useEffect(() => {
    stateRef.current = state;
  }, [state]);

  useEffect(() => {
    if (!loaded) return;
    if (saveTimer.current) clearTimeout(saveTimer.current);
    saveTimer.current = setTimeout(() => {
      persistNow();
    }, 900);
    return () => clearTimeout(saveTimer.current);
  }, [state, loaded, persistNow]);

  const loadLeaderboard = useCallback(async () => {
    setLeaderboardLoading(true);
    try {
      const listResult = await window.storage.list(LEADERBOARD_PREFIX, true);
      const keys = listResult?.keys || [];
      const entries = [];
      for (const k of keys.slice(0, 30)) {
        try {
          const r = await window.storage.get(k, true);
          if (r && r.value) entries.push(JSON.parse(r.value));
        } catch (e) {}
      }
      entries.sort((a, b) => (b.dragonLevel || 0) - (a.dragonLevel || 0));
      setLeaderboard(entries);
    } catch (e) {
      setLeaderboard([]);
    } finally {
      setLeaderboardLoading(false);
    }
  }, []);

  useEffect(() => {
    if (tab === "salao") loadLeaderboard();
  }, [tab, loadLeaderboard]);

  const addFloating = useCallback((text) => {
    const id = floatId.current++;
    const x = 38 + Math.random() * 24;
    setFloatingTexts((prev) => [...prev, { id, text, x }]);
    setTimeout(() => setFloatingTexts((prev) => prev.filter((f) => f.id !== id)), 900);
  }, []);

  useEffect(() => {
    if (!loaded) return;
    const derived = dragonLevelFromPlayer(state.playerLevel);
    if (state.dragonLevel !== derived) {
      setState((prev) => ({ ...prev, dragonLevel: dragonLevelFromPlayer(prev.playerLevel) }));
    }
  }, [state.playerLevel, state.dragonLevel, loaded]);

  const handleClick = () => {
    setState((prev) => {
      const power = playerClickPower(prev);
      let { playerXP, playerLevel } = prev;
      playerXP += 1;
      let leveled = false;
      while (playerXP >= xpToNext(playerLevel)) {
        playerXP -= xpToNext(playerLevel);
        playerLevel += 1;
        leveled = true;
      }
      addFloating(`+${power}${leveled ? "  ⭐" : ""}`);
      return { ...prev, gold: prev.gold + power, playerXP, playerLevel };
    });
  };

  const buyAutoTrainer = () =>
    setState((prev) => {
      if (prev.owned.autoTrainer || prev.gold < AUTO_TRAINER_COST) return prev;
      return { ...prev, gold: prev.gold - AUTO_TRAINER_COST, owned: { ...prev.owned, autoTrainer: true } };
    });

  useEffect(() => {
    if (!loaded || screen !== "game" || !state.owned.autoTrainer || !state.autoTrainOn) return;
    const t = setInterval(() => handleClick(), 1200);
    return () => clearInterval(t);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [loaded, screen, state.owned.autoTrainer, state.autoTrainOn]);

  const buyWeapon = (w) =>
    setState((prev) => {
      if (prev.owned.weapons.includes(w.id)) return prev;
      const cost = costFor(w.baseCost, 0);
      if (prev.gold < cost) return prev;
      return { ...prev, gold: prev.gold - cost, owned: { ...prev.owned, weapons: [...prev.owned.weapons, w.id] } };
    });

  const buyArmor = (a) =>
    setState((prev) => {
      if (prev.owned.armors.includes(a.id)) return prev;
      const cost = costFor(a.baseCost, 0);
      if (prev.gold < cost) return prev;
      return { ...prev, gold: prev.gold - cost, owned: { ...prev.owned, armors: [...prev.owned.armors, a.id] } };
    });

  const buyDecoration = (d) =>
    setState((prev) => {
      if ((prev.owned.decorations || []).includes(d.id)) return prev;
      const cost = costFor(d.baseCost, 0);
      if (prev.gold < cost) return prev;
      return { ...prev, gold: prev.gold - cost, owned: { ...prev.owned, decorations: [...(prev.owned.decorations || []), d.id] } };
    });

  const buyClothing = (slot, item) =>
    setState((prev) => {
      const owns = (prev.owned.clothing || []).includes(item.id);
      const cost = costFor(item.baseCost, 0);
      if (!owns && prev.gold < cost) return prev;
      return {
        ...prev,
        gold: owns ? prev.gold : prev.gold - cost,
        owned: { ...prev.owned, clothing: owns ? prev.owned.clothing : [...(prev.owned.clothing || []), item.id] },
        equipped: { ...prev.equipped, [slot]: item.id },
      };
    });

  const trainAbility = (ab) =>
    setState((prev) => {
      const count = prev.owned.abilities[ab.id] || 0;
      const cost = costFor(ab.baseCost, count);
      if (prev.gold < cost) return prev;
      // Poderes só concedem atributos — o nível do dragão evolui exclusivamente em batalha
      return {
        ...prev,
        gold: prev.gold - cost,
        dragonStats: { ...prev.dragonStats, [ab.stat]: prev.dragonStats[ab.stat] + ab.gain },
        owned: { ...prev.owned, abilities: { ...prev.owned.abilities, [ab.id]: count + 1 } },
      };
    });

  // ---------- Trabalhos ----------
  const startJob = (job) => {
    setState((prev) => {
      if (prev.activeJob) return prev;
      return { ...prev, activeJob: { id: job.id, startTime: Date.now(), endTime: Date.now() + job.durationSec * 1000 } };
    });
  };
  const claimJob = () => {
    setState((prev) => {
      if (!prev.activeJob) return prev;
      const job = JOBS.find((j) => j.id === prev.activeJob.id);
      if (!job || Date.now() < prev.activeJob.endTime) return prev;
      let { playerXP, playerLevel } = prev;
      playerXP += job.xp;
      while (playerXP >= xpToNext(playerLevel)) {
        playerXP -= xpToNext(playerLevel);
        playerLevel += 1;
      }
      addFloating(`+${job.gold} 🪙`);
      return { ...prev, gold: prev.gold + job.gold, playerXP, playerLevel, activeJob: null };
    });
  };

  // ---------- Battle ----------
  const startBattle = (monster) => {
    const maxHp = dragonMaxHP(state);
    setBattle({
      mode: "solo",
      monster,
      monsterHp: monster.hp,
      monsterMaxHp: monster.hp,
      dragonHp: maxHp,
      dragonMaxHp: maxHp,
      log: [`⚔️ ${state.dragonName || "Seu dragão"} enfrenta ${monster.name}!`],
      status: "fighting",
      round: 0,
      anim: null,
    });
  };

  const startArmyBattle = (campaign) => {
    const maxHp = dragonMaxHP(state);
    const firstWave = campaign.waves[0];
    setBattle({
      mode: "army",
      campaign,
      waveIndex: 0,
      monster: firstWave,
      monsterHp: firstWave.hp,
      monsterMaxHp: firstWave.hp,
      dragonHp: maxHp,
      dragonMaxHp: maxHp,
      log: [`🐉 ${state.dragonName || "Seu dragão"} lidera ${state.armyAllies} aliados contra ${campaign.name}!`, `Onda 1/${campaign.waves.length}: ${firstWave.name}`],
      status: "fighting",
      round: 0,
      anim: null,
    });
  };

  const battleRound = () => {
    setBattle((prev) => {
      if (!prev || prev.status !== "fighting") return prev;
      const allyAtk = prev.mode === "army" ? state.armyAllies * ALLY_ATK_BONUS : 0;
      const allyDef = prev.mode === "army" ? state.armyAllies * ALLY_DEF_BONUS : 0;
      const dragonAtk = Math.max(2, state.dragonStats.forca * 1.5 + state.dragonStats.velocidade * 0.5 + allyAtk - prev.monster.def * 1.2);
      const monsterAtk = Math.max(2, prev.monster.atk - state.dragonStats.defesa * 0.7 - allyDef);
      const dmgToMonster = Math.round(dragonAtk * (0.8 + Math.random() * 0.35));
      const dmgToDragon = Math.round(monsterAtk * (0.8 + Math.random() * 0.35));

      const newMonsterHp = Math.max(0, prev.monsterHp - dmgToMonster);
      const log = [...prev.log, `🐲 ataca! ${dmgToMonster} de dano em ${prev.monster.name}`];

      let newDragonHp = prev.dragonHp;
      let status = "fighting";

      if (newMonsterHp <= 0) {
        log.push(`🏆 ${prev.monster.name} foi derrotado!`);
        if (prev.mode === "army" && prev.waveIndex + 1 < prev.campaign.waves.length) {
          const nextWave = prev.campaign.waves[prev.waveIndex + 1];
          const healed = Math.min(prev.dragonMaxHp, prev.dragonHp + Math.round(prev.dragonMaxHp * 0.12));
          log.push(`Onda ${prev.waveIndex + 2}/${prev.campaign.waves.length}: ${nextWave.name}`);
          return {
            ...prev,
            waveIndex: prev.waveIndex + 1,
            monster: nextWave,
            monsterHp: nextWave.hp,
            monsterMaxHp: nextWave.hp,
            dragonHp: healed,
            log,
            status: "fighting",
            round: prev.round + 1,
            anim: { dmgToMonster, dmgToDragon: 0, key: prev.round },
          };
        }
        status = "won";
      } else {
        newDragonHp = Math.max(0, prev.dragonHp - dmgToDragon);
        log.push(`${prev.monster.icon} revida! ${dmgToDragon} de dano em você`);
        if (newDragonHp <= 0) {
          status = "lost";
          log.push(`💀 Seu dragão caiu em batalha...`);
        }
      }

      return {
        ...prev,
        monsterHp: newMonsterHp,
        dragonHp: newDragonHp,
        log,
        status,
        round: prev.round + 1,
        anim: { dmgToMonster, dmgToDragon: newMonsterHp <= 0 ? 0 : dmgToDragon, key: prev.round },
      };
    });
  };

  useEffect(() => {
    if (!battle || battle.status !== "fighting") return;
    const t = setTimeout(battleRound, 900);
    return () => clearTimeout(t);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [battle?.round, battle?.status]);

  const recruitAlly = () => {
    setState((prev) => {
      const cost = costFor(ALLY_BASE_COST, prev.armyAllies);
      if (prev.gold < cost) return prev;
      return { ...prev, gold: prev.gold - cost, armyAllies: prev.armyAllies + 1 };
    });
  };

  const closeBattle = () => {
    if (battle?.status === "won") {
      if (battle.mode === "army") {
        const campaign = battle.campaign;
        const goldReward = Math.round(campaign.goldMin + Math.random() * (campaign.goldMax - campaign.goldMin));
        setState((prev) => ({
          ...prev,
          gold: prev.gold + goldReward,
          battlesWon: prev.battlesWon + 1,
          highestArmyTierCleared: Math.max(prev.highestArmyTierCleared, campaign.tier),
        }));
      } else {
        const monster = battle.monster;
        const goldReward = Math.round(monster.goldMin + Math.random() * (monster.goldMax - monster.goldMin));
        setState((prev) => ({
          ...prev,
          gold: prev.gold + goldReward,
          battlesWon: prev.battlesWon + 1,
          highestTierCleared: Math.max(prev.highestTierCleared, monster.tier),
        }));
      }
    } else if (battle?.status === "lost") {
      setState((prev) => ({ ...prev, gold: Math.floor(prev.gold * 0.8), battlesLost: prev.battlesLost + 1 }));
    }
    setBattle(null);
  };

  const resetGame = async () => {
    try {
      await window.storage.set(STORAGE_KEY, JSON.stringify(defaultState()), false);
    } catch (e) {}
    setState(defaultState());
    setScreen("setup");
  };

  const dragonEvolution = evolutionFor(state.dragonLevel);
  const colorTheme = DRAGON_COLORS.find((c) => c.id === state.colorId) || DRAGON_COLORS[0];

  if (!loaded || screen === "loading") {
    return (
      <div className="min-h-screen flex items-center justify-center bg-black text-red-400 font-serif tracking-widest">
        despertando as trevas...
      </div>
    );
  }

  if (screen === "setup") {
    return <SetupScreen setState={setState} onDone={() => setScreen("game")} />;
  }

  const gps = idleGoldPerSecond(state);
  const clickPower = playerClickPower(state);
  const playerXpNext = xpToNext(state.playerLevel);
  const dragonXpNext = dragonXpToNext(state.dragonLevel);
  const dragonCycleProgress = Math.min(100, Math.round((((state.playerLevel - 1) % 2) + state.playerXP / playerXpNext) * 50));
  const activeJobDef = state.activeJob ? JOBS.find((j) => j.id === state.activeJob.id) : null;
  const jobRemaining = state.activeJob ? Math.max(0, Math.ceil((state.activeJob.endTime - now) / 1000)) : 0;
  const jobReady = state.activeJob && jobRemaining <= 0;

  return (
    <div className="min-h-screen bg-black text-stone-200" style={{ fontFamily: "'Georgia', 'Cinzel', serif" }}>
      <div
        className="fixed inset-0 pointer-events-none opacity-40"
        style={{ background: "radial-gradient(circle at 50% -10%, rgba(122,12,30,0.25), transparent 55%), radial-gradient(circle at 90% 100%, rgba(74,26,92,0.2), transparent 50%)" }}
      />
      <div className="relative max-w-md mx-auto px-4 pb-10 pt-6">
        <div className="text-center mb-4">
          <h1 className="text-2xl font-bold tracking-wider text-red-500 flex items-center justify-center gap-2" style={{ textShadow: "0 0 12px rgba(220,38,38,0.6)" }}>
            <Skull className="w-6 h-6" /> {state.playerName} & {state.dragonName}
          </h1>
          <p className="text-[11px] text-stone-500 mt-1 tracking-wide uppercase">{dragonEvolution.name} · Nível {state.dragonLevel}</p>
          {dragonEvolution.max < 9999 && (
            <p className="text-[10px] text-stone-700 mt-0.5">Próxima evolução no nível {dragonEvolution.max + 1}</p>
          )}
        </div>

        <div className="flex items-center justify-between gap-2 mb-4 bg-stone-950 border border-stone-800 rounded-xl px-3 py-2">
          <div className="text-[10px] text-stone-500">
            {lastSavedAt ? (
              <>Último save: <span className="text-stone-300">{formatSavedAgo(now, lastSavedAt)}</span></>
            ) : (
              "Ainda não salvo"
            )}
          </div>
          <button
            onClick={persistNow}
            className="flex items-center gap-1.5 text-[11px] font-semibold px-3 py-1.5 rounded-lg bg-emerald-800 hover:bg-emerald-700 text-white disabled:opacity-60"
            disabled={saveStatus === "saving"}
          >
            <Save className="w-3.5 h-3.5" />
            {saveStatus === "saving" ? "Salvando..." : saveStatus === "saved" ? "Salvo ✓" : "Salvar agora"}
          </button>
        </div>

        {offlineReport && (
          <div className="bg-red-950/40 border border-red-900 rounded-xl px-4 py-2 mb-4 text-sm text-red-200 flex justify-between items-center">
            <span>Enquanto esteve fora ({Math.floor(offlineReport.seconds / 60)} min), seu covil rendeu <b>{offlineReport.gold} 🪙</b></span>
            <button onClick={() => setOfflineReport(null)} className="text-red-300 hover:text-red-100 text-xs ml-2">✕</button>
          </div>
        )}

        <div className="bg-stone-950 rounded-2xl p-4 mb-4 border border-red-950">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2 text-amber-400 text-xl font-bold">
              <Coins className="w-5 h-5" /> {Math.floor(state.gold).toLocaleString("pt-BR")}
            </div>
            <div className="text-[11px] text-stone-500 text-right">
              <div>+{gps.toFixed(1)} 🪙/seg</div>
              <div>+{clickPower} 🪙/clique</div>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-2 gap-3 mb-3">
          <div className="bg-stone-950 rounded-2xl p-3 border border-stone-800">
            <div className="text-[10px] text-stone-500 uppercase tracking-wide mb-1">{state.playerName}</div>
            <div className="font-semibold flex items-center gap-1 text-sm"><Star className="w-4 h-4 text-yellow-500" /> Nível {state.playerLevel}</div>
            <Bar value={state.playerXP} max={playerXpNext} color="bg-yellow-500" />
            <div className="text-[10px] text-stone-600 mt-1">{state.playerXP}/{playerXpNext} XP</div>
          </div>
          <div className="bg-stone-950 rounded-2xl p-3 border border-stone-800">
            <div className="text-[10px] text-stone-500 uppercase tracking-wide mb-1">{state.dragonName}</div>
            <div className="font-semibold flex items-center gap-1 text-sm"><Flame className="w-4 h-4 text-red-500" /> Nível {state.dragonLevel}</div>
            <Bar value={dragonCycleProgress} max={100} color="bg-red-600" />
            <div className="text-[10px] text-stone-600 mt-1">Evolui junto com você — a cada 2 níveis seus, +1 nível dele</div>
          </div>
        </div>

        <div className="bg-stone-950 rounded-2xl p-3 mb-4 border border-stone-800 flex justify-around text-center text-sm">
          <Stat label="Força" value={state.dragonStats.forca} color="text-red-500" />
          <Stat label="Defesa" value={state.dragonStats.defesa} color="text-blue-400" />
          <Stat label="Veloc." value={state.dragonStats.velocidade} color="text-cyan-300" />
          <Stat label="Vida" value={dragonMaxHP(state)} color="text-emerald-400" />
        </div>

        <div className="relative flex justify-center mb-2">
          <button
            onClick={handleClick}
            className="active:scale-95 transition-transform"
          >
            <DragonAvatar dragonEvolution={dragonEvolution} colorTheme={colorTheme} />
          </button>
          {floatingTexts.map((f) => (
            <span key={f.id} className="absolute top-0 text-amber-400 font-bold text-sm pointer-events-none" style={{ left: `${f.x}%`, animation: "floatUp 0.9s ease-out forwards" }}>
              {f.text}
            </span>
          ))}
        </div>
        <p className="text-center text-[11px] text-stone-600 mb-2 tracking-wide">Toque para treinar seu {dragonEvolution.name.toLowerCase()}</p>

        <div className="flex items-center justify-center gap-2 mb-6">
          {state.owned.autoTrainer ? (
            <button
              onClick={() => setState((prev) => ({ ...prev, autoTrainOn: !prev.autoTrainOn }))}
              className={`flex items-center gap-1.5 text-[11px] font-medium px-3 py-1.5 rounded-lg border ${
                state.autoTrainOn ? "bg-emerald-900/40 border-emerald-700 text-emerald-300" : "bg-stone-950 border-stone-800 text-stone-500"
              }`}
            >
              <MousePointerClick className="w-3.5 h-3.5" /> Treino automático: {state.autoTrainOn ? "Ligado" : "Desligado"}
            </button>
          ) : (
            <button
              onClick={buyAutoTrainer}
              disabled={state.gold < AUTO_TRAINER_COST}
              className={`flex items-center gap-1.5 text-[11px] font-medium px-3 py-1.5 rounded-lg border ${
                state.gold < AUTO_TRAINER_COST ? "bg-stone-950 border-stone-800 text-stone-600 cursor-not-allowed" : "bg-purple-900/40 border-purple-700 text-purple-300"
              }`}
            >
              <MousePointerClick className="w-3.5 h-3.5" /> Comprar Treinador Automático · {AUTO_TRAINER_COST.toLocaleString("pt-BR")} 🪙
            </button>
          )}
        </div>

        <div className="grid grid-cols-6 bg-stone-950 rounded-xl p-1 mb-3 border border-stone-800 gap-0.5">
          {[
            { key: "lar", icon: Home },
            { key: "armas", icon: Sword },
            { key: "armaduras", icon: Shield },
            { key: "habilidades", icon: Zap },
            { key: "trabalhos", icon: Briefcase },
            { key: "batalha", icon: Swords },
          ].map(({ key, icon: Icon }) => (
            <button
              key={key}
              onClick={() => setTab(key)}
              className={`flex flex-col items-center justify-center gap-0.5 py-2 rounded-lg text-[9px] font-medium transition-colors ${
                tab === key ? "bg-red-800 text-white" : "text-stone-500"
              }`}
            >
              <Icon className="w-3.5 h-3.5" />
              {key === "lar" ? "Lar" : key === "armas" ? "Armas" : key === "armaduras" ? "Armad." : key === "habilidades" ? "Poderes" : key === "trabalhos" ? "Trab." : "Luta"}
            </button>
          ))}
        </div>
        <button
          onClick={() => setTab("salao")}
          className={`w-full mb-2 flex items-center justify-center gap-1.5 py-2 rounded-lg text-[11px] font-medium border ${
            tab === "salao" ? "bg-amber-800 text-white border-amber-700" : "bg-stone-950 text-stone-400 border-stone-800"
          }`}
        >
          <Trophy className="w-3.5 h-3.5" /> Salão da Fama (multiplayer)
        </button>
        <div className="grid grid-cols-2 gap-2 mb-3">
          <button
            onClick={() => setTab("personagem")}
            className={`flex items-center justify-center gap-1.5 py-2 rounded-lg text-[11px] font-medium border ${
              tab === "personagem" ? "bg-purple-900 text-white border-purple-700" : "bg-stone-950 text-stone-400 border-stone-800"
            }`}
          >
            <User className="w-3.5 h-3.5" /> Personagem
          </button>
          <button
            onClick={() => setTab("jornada")}
            className={`flex items-center justify-center gap-1.5 py-2 rounded-lg text-[11px] font-medium border ${
              tab === "jornada" ? "bg-emerald-900 text-white border-emerald-700" : "bg-stone-950 text-stone-400 border-stone-800"
            }`}
          >
            <BookOpen className="w-3.5 h-3.5" /> A Saga
          </button>
        </div>

        <div className="space-y-2">
          {tab === "lar" && (
            <div>
              <div className="bg-gradient-to-b from-stone-900 to-black rounded-2xl border border-stone-800 p-6 mb-3 text-center relative overflow-hidden">
                <div className="absolute inset-0 opacity-20" style={{ background: "radial-gradient(circle at 50% 30%, rgba(220,38,38,0.4), transparent 60%)" }} />
                <div className="relative flex justify-center gap-4 items-end mb-2">
                  <CharacterAvatar state={state} />
                  <DragonAvatar dragonEvolution={dragonEvolution} colorTheme={colorTheme} sizeClass="w-20 h-20" fontScale={2.2} />
                </div>
                <div className="relative text-xs text-stone-400">
                  Covil de <b className="text-stone-200">{state.playerName}</b> e <b className="text-stone-200">{state.dragonName}</b>
                </div>
                <div className="relative text-[10px] text-stone-600 mt-1">{DECORATIONS.filter((d) => (state.owned.decorations || []).includes(d.id)).map((d) => d.icon).join(" ") || "Um covil vazio e sombrio..."}</div>
              </div>
              <div className="text-[11px] text-stone-500 px-1 mb-1">Decore seu lar para aumentar a geração passiva de ouro.</div>
              {DECORATIONS.map((d) => (
                <ShopRow key={d.id} icon={d.icon} name={d.name} detail={`+${Math.round(d.idleBonus * 100)}% ouro passivo`} cost={costFor(d.baseCost, 0)} owned={(state.owned.decorations || []).includes(d.id)} disabled={state.gold < costFor(d.baseCost, 0)} onBuy={() => buyDecoration(d)} />
              ))}
            </div>
          )}

          {tab === "armas" && WEAPONS.map((w) => (
            <ShopRow key={w.id} icon={w.icon} name={w.name} detail={`+${w.clickBonus} por clique`} cost={costFor(w.baseCost, 0)} owned={state.owned.weapons.includes(w.id)} disabled={state.gold < costFor(w.baseCost, 0)} onBuy={() => buyWeapon(w)} />
          ))}

          {tab === "armaduras" && ARMORS.map((a) => (
            <ShopRow key={a.id} icon={a.icon} name={a.name} detail={`+${Math.round(a.idlePercent * 100)}% ouro passivo`} cost={costFor(a.baseCost, 0)} owned={state.owned.armors.includes(a.id)} disabled={state.gold < costFor(a.baseCost, 0)} onBuy={() => buyArmor(a)} />
          ))}

          {tab === "habilidades" && (
            <>
              <p className="text-[11px] text-stone-500 px-1 mb-1">Poderes aumentam os atributos de combate do dragão, mas não dão nível. Só vencer batalhas evolui seu dragão de verdade.</p>
              {ABILITIES.map((ab) => {
                const count = state.owned.abilities[ab.id] || 0;
                const cost = costFor(ab.baseCost, count);
                return (
                  <ShopRow key={ab.id} icon={ab.icon} name={ab.name} detail={`+${ab.gain} ${ab.stat} · treinado ${count}x`} cost={cost} owned={false} disabled={state.gold < cost} onBuy={() => trainAbility(ab)} buyLabel="Treinar" />
                );
              })}
            </>
          )}

          {tab === "trabalhos" && (
            <div className="space-y-2">
              <p className="text-[11px] text-stone-500 px-1 mb-1">Envie {state.playerName} para trabalhos. Ele fica ausente por um tempo real e volta com ouro e experiência.</p>
              {state.activeJob && activeJobDef && (
                <div className="bg-amber-950/30 border border-amber-800 rounded-xl p-3 flex items-center justify-between">
                  <div className="flex items-center gap-2 text-sm">
                    <span className="text-xl">{activeJobDef.icon}</span>
                    <div>
                      <div className="font-medium">{activeJobDef.name}</div>
                      <div className="text-[11px] text-stone-400 flex items-center gap-1">
                        <Clock className="w-3 h-3" /> {jobReady ? "Concluído!" : `${jobRemaining}s restantes`}
                      </div>
                    </div>
                  </div>
                  <button
                    onClick={claimJob}
                    disabled={!jobReady}
                    className={`text-xs font-semibold px-3 py-1.5 rounded-lg ${jobReady ? "bg-emerald-700 text-white" : "bg-stone-800 text-stone-600 cursor-not-allowed"}`}
                  >
                    Coletar
                  </button>
                </div>
              )}
              {JOBS.map((j) => (
                <div key={j.id} className="bg-stone-950 rounded-xl p-3 border border-stone-800 flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className="text-2xl">{j.icon}</div>
                    <div>
                      <div className="text-sm font-medium">{j.name}</div>
                      <div className="text-[11px] text-stone-500">{j.durationSec >= 60 ? `${Math.round(j.durationSec / 60)} min` : `${j.durationSec}s`} · +{j.gold} 🪙 · +{j.xp} XP</div>
                    </div>
                  </div>
                  <button
                    onClick={() => startJob(j)}
                    disabled={!!state.activeJob}
                    className={`text-xs font-semibold px-3 py-1.5 rounded-lg ${state.activeJob ? "bg-stone-800 text-stone-600 cursor-not-allowed" : "bg-red-800 hover:bg-red-700 text-white"}`}
                  >
                    Enviar
                  </button>
                </div>
              ))}
            </div>
          )}

          {tab === "batalha" && (
            <div className="space-y-2">
              <p className="text-[11px] text-stone-500 px-1 mb-1">
                Seu dragão luta ao seu lado desde o ovo. Monstros cada vez mais fortes — se ele superar seu dragão, você perde a luta e 20% do ouro. Veja a aba <b>A Saga</b> para a história por trás de cada batalha.
              </p>
              {MONSTERS.map((m) => {
                const locked = m.tier > state.highestTierCleared + 1;
                return (
                  <button
                    key={m.tier}
                    onClick={() => !locked && startBattle(m)}
                    disabled={locked}
                    className={`w-full bg-stone-950 rounded-xl p-3 border flex items-center justify-between transition-colors ${locked ? "border-stone-900 opacity-40 cursor-not-allowed" : "border-red-950 hover:border-red-700"}`}
                  >
                    <div className="flex items-center gap-3">
                      <div className="text-2xl">{locked ? "🔒" : m.icon}</div>
                      <div className="text-left">
                        <div className="text-sm font-medium flex items-center gap-1.5">
                          {m.name}
                          <span className="text-[9px] bg-red-900/60 text-red-300 px-1.5 py-0.5 rounded-full">Dif. {m.tier}</span>
                        </div>
                        <div className="text-[11px] text-stone-500">HP {m.hp} · ATK {m.atk} · DEF {m.def}</div>
                      </div>
                    </div>
                    <ChevronRight className="w-4 h-4 text-stone-600" />
                  </button>
                );
              })}
              <div className="text-[10px] text-stone-600 text-center pt-2">Vitórias: {state.battlesWon} · Derrotas: {state.battlesLost}</div>

              <div className="pt-4 mt-2 border-t border-stone-800">
                <div className="text-sm font-semibold text-amber-400 mb-1 flex items-center gap-1.5"><Users className="w-4 h-4" /> Batalhas de Exército</div>
                <p className="text-[11px] text-stone-500 mb-2">Recrute aliados e enfrente hordas em várias ondas seguidas. Seu dragão só se recupera parcialmente entre ondas.</p>
                <div className="bg-stone-950 rounded-xl p-3 border border-amber-900/40 flex items-center justify-between mb-2">
                  <div className="text-sm">
                    <div className="font-medium">Aliados recrutados: {state.armyAllies}</div>
                    <div className="text-[10px] text-stone-500">+{ALLY_ATK_BONUS} ataque e +{ALLY_DEF_BONUS} defesa cada, só em exércitos</div>
                  </div>
                  <button onClick={recruitAlly} disabled={state.gold < costFor(ALLY_BASE_COST, state.armyAllies)} className={`text-xs font-semibold px-3 py-1.5 rounded-lg flex items-center gap-1 ${state.gold < costFor(ALLY_BASE_COST, state.armyAllies) ? "bg-stone-800 text-stone-600 cursor-not-allowed" : "bg-amber-800 hover:bg-amber-700 text-white"}`}>
                    <Coins className="w-3 h-3" /> {costFor(ALLY_BASE_COST, state.armyAllies).toLocaleString("pt-BR")}
                  </button>
                </div>
                {ARMY_CAMPAIGNS.map((c) => {
                  const locked = c.tier > state.highestArmyTierCleared + 1;
                  return (
                    <button
                      key={c.tier}
                      onClick={() => !locked && startArmyBattle(c)}
                      disabled={locked}
                      className={`w-full bg-stone-950 rounded-xl p-3 border flex items-center justify-between transition-colors mb-2 ${locked ? "border-stone-900 opacity-40 cursor-not-allowed" : "border-amber-800 hover:border-amber-600"}`}
                    >
                      <div className="flex items-center gap-3">
                        <div className="text-2xl">{locked ? "🔒" : "⚔️"}</div>
                        <div className="text-left">
                          <div className="text-sm font-medium">{c.name}</div>
                          <div className="text-[11px] text-stone-500">{c.waves.length} ondas · {c.waves.map((w) => w.icon).join(" ")}</div>
                        </div>
                      </div>
                      <ChevronRight className="w-4 h-4 text-stone-600" />
                    </button>
                  );
                })}
              </div>
            </div>
          )}

          {tab === "salao" && (
            <div className="space-y-2">
              <p className="text-[11px] text-stone-500 px-1 mb-1">
                Ranking compartilhado entre todos que jogam este RPG agora. Seus dados são publicados automaticamente aqui para outros verem.
              </p>
              {leaderboardLoading && <div className="text-center text-xs text-stone-500 py-4">Consultando outros domadores...</div>}
              {!leaderboardLoading && leaderboard.length === 0 && (
                <div className="text-center text-xs text-stone-500 py-4">Ainda não há outros domadores registrados. Seja o primeiro a evoluir!</div>
              )}
              {leaderboard.map((p, i) => (
                <div key={i} className={`bg-stone-950 rounded-xl p-3 border flex items-center justify-between ${p.playerName === state.playerName && p.dragonName === state.dragonName ? "border-amber-700" : "border-stone-800"}`}>
                  <div className="flex items-center gap-3">
                    <div className="text-xs text-stone-600 w-5">#{i + 1}</div>
                    <div className={`w-9 h-9 rounded-full bg-gradient-to-br ${(DRAGON_COLORS.find((c) => c.id === p.colorId) || DRAGON_COLORS[0]).grad} flex items-center justify-center text-lg`}>🐉</div>
                    <div>
                      <div className="text-sm font-medium">{p.dragonName} <span className="text-stone-500 font-normal">de {p.playerName}</span></div>
                      <div className="text-[10px] text-stone-500">Nível {p.dragonLevel} · {p.battlesWon || 0} vitórias · dif. máx. {p.highestTierCleared || 0}</div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}

          {tab === "personagem" && (
            <div className="space-y-3">
              <div className="bg-gradient-to-b from-purple-950/30 to-black rounded-2xl border border-purple-900/50 p-6 text-center">
                <CharacterAvatar state={state} size="text-7xl" />
                <div className="text-sm font-medium mt-2">{state.playerName}</div>
                <div className="text-[11px] text-stone-500">{CLASSES.find((c) => c.id === state.classId)?.name} · Nível {state.playerLevel}</div>
              </div>
              {Object.entries(CLOTHING).map(([slot, items]) => (
                <div key={slot}>
                  <div className="text-[11px] text-stone-500 uppercase tracking-wide px-1 mb-1 mt-2">{CLOTHING_SLOT_LABELS[slot]}</div>
                  <div className="space-y-2">
                    {items.map((item) => {
                      const owned = (state.owned.clothing || []).includes(item.id);
                      const equipped = state.equipped?.[slot] === item.id;
                      const cost = costFor(item.baseCost, 0);
                      return (
                        <div key={item.id} className="bg-stone-950 rounded-xl p-3 border border-stone-800 flex items-center justify-between">
                          <div className="flex items-center gap-3">
                            <div className="text-2xl">{item.icon}</div>
                            <div className="text-sm font-medium">{item.name}</div>
                          </div>
                          <button
                            onClick={() => buyClothing(slot, item)}
                            disabled={!owned && state.gold < cost}
                            className={`text-xs font-semibold px-3 py-1.5 rounded-lg flex items-center gap-1 ${
                              equipped
                                ? "bg-emerald-800 text-white"
                                : owned
                                ? "bg-stone-800 text-stone-200"
                                : state.gold < cost
                                ? "bg-stone-800 text-stone-600 cursor-not-allowed"
                                : "bg-purple-800 hover:bg-purple-700 text-white"
                            }`}
                          >
                            {equipped ? "Equipado" : owned ? "Usar" : (<><Coins className="w-3 h-3" /> {cost.toLocaleString("pt-BR")}</>)}
                          </button>
                        </div>
                      );
                    })}
                  </div>
                </div>
              ))}
            </div>
          )}

          {tab === "jornada" && (
            <div className="space-y-3">
              <div className="bg-gradient-to-b from-emerald-950/20 to-black rounded-2xl border border-emerald-900/40 p-4">
                <div className="text-sm font-semibold text-emerald-400 mb-1">A Saga dos Domadores</div>
                <p className="text-[12px] text-stone-400 leading-relaxed">
                  Há eras, a Legião das Escamas Negras corrompeu dragões ancestrais e os voltou contra o mundo. A Ordem dos Domadores
                  existe para reverter esse mal: treinar domadores e dragões livres até formarem um exército capaz de enfrentar a
                  Legião e libertar os dragões escravizados. Cada monstro vencido é um passo dessa guerra.
                </p>
              </div>
              {CHAPTERS.map((c) => {
                const done = state.highestTierCleared >= c.tier;
                const current = state.highestTierCleared + 1 === c.tier;
                const locked = c.tier > state.highestTierCleared + 1;
                return (
                  <div key={c.tier} className={`rounded-xl p-3 border ${done ? "border-emerald-800 bg-emerald-950/20" : current ? "border-amber-700 bg-amber-950/20" : "border-stone-900 bg-stone-950 opacity-60"}`}>
                    <div className="flex items-center justify-between mb-1">
                      <div className="text-sm font-medium flex items-center gap-1.5">
                        {locked && <Lock className="w-3 h-3 text-stone-600" />}
                        {c.title}
                      </div>
                      {done && <span className="text-[9px] bg-emerald-900 text-emerald-300 px-1.5 py-0.5 rounded-full">Concluído</span>}
                      {current && <span className="text-[9px] bg-amber-900 text-amber-300 px-1.5 py-0.5 rounded-full">Atual</span>}
                    </div>
                    <p className="text-[11px] text-stone-500 leading-relaxed">{c.text}</p>
                  </div>
                );
              })}
            </div>
          )}
        </div>

        <button onClick={resetGame} className="mt-8 w-full text-[10px] text-stone-700 hover:text-red-500 flex items-center justify-center gap-1 py-2">
          <RotateCcw className="w-3 h-3" /> Reiniciar jornada
        </button>
      </div>

      {battle && <BattleModal battle={battle} colorTheme={colorTheme} dragonEvolution={dragonEvolution} onClose={closeBattle} />}

      <style>{`
        @keyframes floatUp { 0% { transform: translateY(0); opacity: 1; } 100% { transform: translateY(-40px); opacity: 0; } }
        @keyframes lungeRight { 0% { transform: translateX(0); } 40% { transform: translateX(18px); } 100% { transform: translateX(0); } }
        @keyframes lungeLeft { 0% { transform: translateX(0); } 40% { transform: translateX(-18px); } 100% { transform: translateX(0); } }
        @keyframes shake { 0%,100% { transform: translateX(0); } 20% { transform: translateX(-5px); } 40% { transform: translateX(5px); } 60% { transform: translateX(-4px); } 80% { transform: translateX(4px); } }
        @keyframes dmgFloat { 0% { transform: translateY(0); opacity: 1; } 100% { transform: translateY(-30px); opacity: 0; } }
        @keyframes pulseRing { 0%,100% { opacity: 0.5; transform: scale(1); } 50% { opacity: 0.1; transform: scale(1.08); } }
      `}</style>
    </div>
  );
}

/* =========================================================
   SETUP SCREEN
   ========================================================= */
function SetupScreen({ setState, onDone }) {
  const [step, setStep] = useState(0);
  const [playerName, setPlayerName] = useState("");
  const [dragonName, setDragonName] = useState("");
  const [classId, setClassId] = useState("guerreiro");
  const [colorId, setColorId] = useState("sangue");
  const color = DRAGON_COLORS.find((c) => c.id === colorId);

  const finish = () => {
    setState((prev) => ({
      ...prev,
      setupDone: true,
      playerName: playerName.trim() || "Domador Sem Nome",
      dragonName: dragonName.trim() || "O Inominável",
      classId,
      colorId,
      dragonStats: { ...prev.dragonStats, ...(CLASSES.find((c) => c.id === classId)?.statBonus || {}) },
    }));
    onDone();
  };

  return (
    <div className="min-h-screen bg-black text-stone-200 flex flex-col items-center justify-center px-6" style={{ fontFamily: "'Georgia', serif" }}>
      <div className="fixed inset-0 pointer-events-none opacity-50" style={{ background: "radial-gradient(circle at 50% 20%, rgba(122,12,30,0.3), transparent 60%)" }} />
      <div className="relative w-full max-w-sm">
        <h1 className="text-center text-2xl font-bold text-red-500 mb-1 tracking-wide" style={{ textShadow: "0 0 14px rgba(220,38,38,0.6)" }}>Forje seu Destino</h1>
        <p className="text-center text-[11px] text-stone-500 mb-6 uppercase tracking-widest">Passo {step + 1} de 3</p>

        {step === 0 && (
          <div className="space-y-4">
            <Field label="Nome do domador">
              <input value={playerName} onChange={(e) => setPlayerName(e.target.value)} maxLength={18} placeholder="Ex: Kaelen" className="w-full bg-stone-950 border border-stone-800 focus:border-red-700 rounded-lg px-3 py-2 text-sm outline-none" />
            </Field>
            <Field label="Nome do dragão">
              <input value={dragonName} onChange={(e) => setDragonName(e.target.value)} maxLength={18} placeholder="Ex: Sombranegra" className="w-full bg-stone-950 border border-stone-800 focus:border-red-700 rounded-lg px-3 py-2 text-sm outline-none" />
            </Field>
            <button onClick={() => setStep(1)} disabled={!playerName.trim() || !dragonName.trim()} className="w-full bg-red-800 disabled:bg-stone-800 disabled:text-stone-600 rounded-lg py-2.5 text-sm font-semibold mt-2">Continuar</button>
          </div>
        )}

        {step === 1 && (
          <div className="space-y-3">
            <div className="text-[11px] text-stone-500 uppercase tracking-widest mb-1">Escolha sua classe</div>
            {CLASSES.map((c) => (
              <button key={c.id} onClick={() => setClassId(c.id)} className={`w-full flex items-center gap-3 p-3 rounded-xl border text-left transition-colors ${classId === c.id ? "border-red-700 bg-red-950/30" : "border-stone-800 bg-stone-950"}`}>
                <div className="text-2xl">{c.icon}</div>
                <div><div className="text-sm font-medium">{c.name}</div><div className="text-[11px] text-stone-500">{c.desc}</div></div>
              </button>
            ))}
            <button onClick={() => setStep(2)} className="w-full bg-red-800 rounded-lg py-2.5 text-sm font-semibold mt-2">Continuar</button>
          </div>
        )}

        {step === 2 && (
          <div className="space-y-4">
            <div className="text-[11px] text-stone-500 uppercase tracking-widest mb-1">Escolha a linhagem do dragão</div>
            <div className="flex justify-center mb-2">
              <div className={`w-28 h-28 rounded-full bg-gradient-to-br ${color.grad} shadow-2xl ${color.glow} ring-2 ${color.ring} flex items-center justify-center text-5xl`}>🥚</div>
            </div>
            <div className="grid grid-cols-5 gap-2">
              {DRAGON_COLORS.map((c) => (
                <button key={c.id} onClick={() => setColorId(c.id)} className={`aspect-square rounded-full bg-gradient-to-br ${c.grad} ring-2 ${colorId === c.id ? c.ring : "ring-transparent"}`} title={c.name} />
              ))}
            </div>
            <div className="text-center text-xs text-stone-400">{color.name}</div>
            <button onClick={finish} className="w-full bg-red-800 rounded-lg py-2.5 text-sm font-semibold mt-2">Selar o pacto</button>
          </div>
        )}
      </div>
    </div>
  );
}

function Field({ label, children }) {
  return (
    <div>
      <div className="text-[11px] text-stone-500 uppercase tracking-widest mb-1">{label}</div>
      {children}
    </div>
  );
}

/* =========================================================
   BATTLE MODAL — visual e animado
   ========================================================= */
function BattleModal({ battle, colorTheme, dragonEvolution, onClose }) {
  const { monster, monsterHp, monsterMaxHp, dragonHp, dragonMaxHp, log, status, anim, mode, campaign, waveIndex } = battle;
  const logRef = useRef(null);

  useEffect(() => {
    if (logRef.current) logRef.current.scrollTop = logRef.current.scrollHeight;
  }, [log]);

  const dragonHit = anim && anim.dmgToDragon > 0;
  const monsterHit = anim && anim.dmgToMonster > 0;

  return (
    <div className="fixed inset-0 bg-black/90 z-50 flex items-center justify-center px-4">
      <div className="w-full max-w-sm bg-stone-950 border border-red-950 rounded-2xl p-4 shadow-2xl shadow-red-950/50">
        {mode === "army" && (
          <div className="text-center text-[11px] text-amber-400 font-medium mb-2">{campaign.name} · Onda {waveIndex + 1}/{campaign.waves.length}</div>
        )}
        <div className="flex items-center justify-between mb-3 relative h-20">
          <div
            key={anim ? `d-${anim.key}` : "d"}
            className="w-16 h-16 relative"
            style={{ animation: status === "fighting" ? "lungeRight 0.5s ease-out" : dragonHit ? "shake 0.4s" : "none" }}
          >
            <DragonAvatar dragonEvolution={dragonEvolution} colorTheme={colorTheme} sizeClass="w-16 h-16" />
            {dragonHit && (
              <span className="absolute -top-3 right-0 text-red-500 font-bold text-xs" style={{ animation: "dmgFloat 0.8s ease-out forwards" }}>
                -{anim.dmgToDragon}
              </span>
            )}
          </div>
          <Swords className="w-6 h-6 text-red-600" />
          <div
            key={anim ? `m-${anim.key}` : "m"}
            className="w-16 h-16 rounded-full bg-gradient-to-br from-stone-800 to-stone-950 flex items-center justify-center text-3xl ring-2 ring-stone-700 relative"
            style={{ animation: monsterHit ? "shake 0.4s" : "none" }}
          >
            {monster.icon}
            {monsterHit && (
              <span className="absolute -top-3 left-0 text-orange-400 font-bold text-xs" style={{ animation: "dmgFloat 0.8s ease-out forwards" }}>
                -{anim.dmgToMonster}
              </span>
            )}
          </div>
        </div>

        <div className="grid grid-cols-2 gap-3 mb-3">
          <div>
            <div className="text-[10px] text-stone-500 mb-1">Seu dragão</div>
            <Bar value={dragonHp} max={dragonMaxHp} color={dragonHp < dragonMaxHp * 0.3 ? "bg-red-600" : "bg-emerald-500"} />
            <div className="text-[10px] text-stone-500 mt-0.5">{Math.round(dragonHp)}/{dragonMaxHp} HP</div>
          </div>
          <div>
            <div className="text-[10px] text-stone-500 mb-1">{monster.name}</div>
            <Bar value={monsterHp} max={monsterMaxHp} color="bg-orange-600" />
            <div className="text-[10px] text-stone-500 mt-0.5">{Math.round(monsterHp)}/{monsterMaxHp} HP</div>
          </div>
        </div>

        <div ref={logRef} className="bg-black/50 rounded-lg p-2 h-28 overflow-y-auto text-[11px] text-stone-400 space-y-1 mb-3 border border-stone-900">
          {log.map((l, i) => <div key={i}>{l}</div>)}
        </div>

        {status === "fighting" && <div className="text-center text-[11px] text-stone-500 animate-pulse">Combate em andamento...</div>}

        {status === "won" && (
          <div className="text-center">
            <div className="text-emerald-400 font-semibold text-sm mb-2 flex items-center justify-center gap-1"><Star className="w-4 h-4" /> Vitória! Seu dragão evoluiu com a batalha.</div>
            <button onClick={onClose} className="w-full bg-emerald-800 rounded-lg py-2 text-sm font-semibold">Coletar recompensa</button>
          </div>
        )}

        {status === "lost" && (
          <div className="text-center">
            <div className="text-red-500 font-semibold text-sm mb-2 flex items-center justify-center gap-1"><ShieldAlert className="w-4 h-4" /> Derrota. Treine mais antes de tentar de novo.</div>
            <button onClick={onClose} className="w-full bg-stone-800 rounded-lg py-2 text-sm font-semibold">Recuar</button>
          </div>
        )}
      </div>
    </div>
  );
}

/* =========================================================
   AVATARES — tenta carregar arte real (public/images) e usa o
   desenho SVG como visual de reserva automaticamente se não existir
   ========================================================= */
const CLASS_ACCENT = { guerreiro: "#ef4444", cacador: "#4ade80", arcanista: "#a855f7" };

function CharacterAvatar({ state, size = "text-5xl" }) {
  const [imgFailed, setImgFailed] = useState(false);
  const helmetTier = CLOTHING.helmet.findIndex((h) => h.id === state.equipped?.helmet);
  const cloakTier = CLOTHING.cloak.findIndex((c) => c.id === state.equipped?.cloak);
  const weaponTier = CLOTHING.weapon_visual.findIndex((w) => w.id === state.equipped?.weapon_visual);
  const accent = CLASS_ACCENT[state.classId] || "#ef4444";
  const px = { "text-5xl": 72, "text-7xl": 108 }[size] || 84;
  const imgSrc = `${IMG_BASE}/characters/${state.classId}.png`;

  if (!imgFailed) {
    return (
      <div className="relative inline-flex items-center justify-center" style={{ width: px, height: px }}>
        <img
          src={imgSrc}
          alt={state.playerName}
          className="w-full h-full object-contain drop-shadow-[0_0_10px_rgba(0,0,0,0.6)]"
          onError={() => setImgFailed(true)}
        />
      </div>
    );
  }

  return (
    <div className="relative inline-flex items-center justify-center" style={{ width: px, height: px }}>
      <svg viewBox="0 0 100 100" width={px} height={px}>
        <defs>
          <radialGradient id={`char-aura-${state.classId}`} cx="50%" cy="42%" r="55%">
            <stop offset="0%" stopColor={accent} stopOpacity="0.35" />
            <stop offset="100%" stopColor={accent} stopOpacity="0" />
          </radialGradient>
          <linearGradient id="char-cloak" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor={cloakTier >= 2 ? "#3b0764" : cloakTier >= 1 ? "#1f2937" : "#292524"} />
            <stop offset="100%" stopColor="#0c0a09" />
          </linearGradient>
          <linearGradient id="char-skin" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor="#57534e" />
            <stop offset="100%" stopColor="#292524" />
          </linearGradient>
        </defs>

        <circle cx="50" cy="46" r="42" fill={`url(#char-aura-${state.classId})`} />

        {/* manto */}
        <path d="M50 30 L82 92 L18 92 Z" fill="url(#char-cloak)" stroke={cloakTier >= 0 ? accent : "#44403c"} strokeOpacity="0.5" strokeWidth="1.2" />
        {cloakTier >= 2 && <path d="M50 30 L82 92 L18 92 Z" fill="none" stroke={accent} strokeOpacity="0.5" strokeWidth="0.6" strokeDasharray="2 3" />}

        {/* corpo */}
        <rect x="38" y="42" width="24" height="34" rx="10" fill="url(#char-skin)" />

        {/* cabeça */}
        <circle cx="50" cy="34" r="14" fill="#78716c" />
        <circle cx="50" cy="34" r="14" fill="url(#char-skin)" opacity="0.5" />

        {/* capuz/elmo */}
        {helmetTier < 0 ? (
          <path d="M36 30 Q50 12 64 30 Q64 22 50 20 Q36 22 36 30 Z" fill="#1c1917" />
        ) : (
          <path
            d="M34 31 Q50 8 66 31 L66 24 Q50 6 34 24 Z"
            fill={helmetTier >= 2 ? "#facc15" : helmetTier >= 1 ? "#57534e" : "#3f3f46"}
            stroke={accent}
            strokeWidth="0.8"
          />
        )}

        {/* olhos brilhando */}
        <circle cx="45" cy="35" r="1.6" fill={accent} />
        <circle cx="55" cy="35" r="1.6" fill={accent} />
        <circle cx="45" cy="35" r="3.2" fill={accent} opacity="0.35" />
        <circle cx="55" cy="35" r="3.2" fill={accent} opacity="0.35" />

        {/* arma */}
        {weaponTier >= 0 && (
          <g transform="rotate(28 74 60)">
            <rect x="72" y="30" width="3.2" height="42" rx="1.4" fill={weaponTier >= 2 ? "#f87171" : "#d6d3d1"} stroke="#1c1917" strokeWidth="0.6" />
            <rect x="68" y="28" width="11" height="4" rx="1.5" fill={weaponTier >= 2 ? "#facc15" : "#78716c"} />
          </g>
        )}

        {/* cinto/detalhe de classe */}
        <rect x="38" y="62" width="24" height="4" fill={accent} opacity="0.8" />
      </svg>
    </div>
  );
}

function DragonAvatar({ dragonEvolution, colorTheme, sizeClass = "w-40 h-40", fontScale = 3.5 }) {
  const [imgFailed, setImgFailed] = useState(false);
  const pxMap = { "w-40 h-40": 160, "w-20 h-20": 80, "w-16 h-16": 64, "w-28 h-28": 112, "w-9 h-9": 36 };
  const px = pxMap[sizeClass] || 160;
  const imgSrc = `${IMG_BASE}/dragons/${colorTheme.id}/${dragonEvolution.imgKey}.png`;

  if (!imgFailed) {
    return (
      <div className={`relative ${sizeClass} flex items-center justify-center select-none`}>
        <div
          className="absolute inset-0 rounded-full"
          style={{ background: `radial-gradient(circle at 50% 45%, ${colorTheme.light}33, transparent 65%)`, boxShadow: `0 0 ${px * 0.25}px ${colorTheme.light}55` }}
        />
        <img
          src={imgSrc}
          alt={dragonEvolution.name}
          className="relative object-contain drop-shadow-[0_0_14px_rgba(0,0,0,0.6)]"
          style={{ width: px * dragonEvolution.scale, height: px * dragonEvolution.scale }}
          onError={() => setImgFailed(true)}
        />
      </div>
    );
  }

  const kind = dragonEvolution.kind;
  const scale = dragonEvolution.scale;
  const wingTier = dragonEvolution.wingTier || 1;
  const gid = `${colorTheme.id}-${kind}`;

  return (
    <div className={`relative ${sizeClass} rounded-full flex items-center justify-center select-none overflow-visible`}>
      <div
        className="absolute inset-0 rounded-full"
        style={{
          background: `radial-gradient(circle at 50% 45%, ${colorTheme.light}33, transparent 65%)`,
          boxShadow: `0 0 ${px * 0.25}px ${colorTheme.light}55`,
        }}
      />
      {dragonEvolution.min >= 18 && (
        <span
          className="absolute inset-[-6px] rounded-full pointer-events-none"
          style={{ border: `1px solid ${colorTheme.light}55`, animation: "pulseRing 2.4s ease-in-out infinite" }}
        />
      )}
      <svg viewBox="0 0 120 120" width={px * scale * 0.9} height={px * scale * 0.9} className="relative">
        <defs>
          <radialGradient id={`body-${gid}`} cx="45%" cy="35%" r="65%">
            <stop offset="0%" stopColor={colorTheme.light} />
            <stop offset="55%" stopColor={colorTheme.hex} />
            <stop offset="100%" stopColor={colorTheme.dark} />
          </radialGradient>
          <linearGradient id={`wing-${gid}`} x1="0" y1="0" x2="1" y2="1">
            <stop offset="0%" stopColor={colorTheme.hex} stopOpacity="0.95" />
            <stop offset="100%" stopColor={colorTheme.dark} stopOpacity="0.9" />
          </linearGradient>
        </defs>

        {kind === "egg" || kind === "cracked" ? (
          <>
            <ellipse cx="60" cy="66" rx="30" ry="38" fill={`url(#body-${gid})`} stroke={colorTheme.dark} strokeWidth="2" />
            <ellipse cx="52" cy="48" rx="10" ry="7" fill="#ffffff" opacity="0.12" />
            {kind === "cracked" && (
              <>
                <path d="M40 50 L52 60 L44 66 L60 82 L54 68 L64 64 L52 46 Z" fill="none" stroke="#fff7ed" strokeWidth="2.2" strokeLinejoin="round" opacity="0.85" />
                <path d="M40 50 L52 60 L44 66 L60 82 L54 68 L64 64 L52 46 Z" fill={colorTheme.dark} opacity="0.3" />
              </>
            )}
          </>
        ) : (
          <>
            {/* asas traseiras */}
            {wingTier >= 3 && (
              <>
                <path d={`M60 55 C ${30 - wingTier * 6} ${35 - wingTier * 4}, ${10 - wingTier * 4} ${58 - wingTier * 2}, 22 74 C 34 66, 46 60, 60 60 Z`} fill={`url(#wing-${gid})`} opacity="0.85" />
                <path d={`M60 55 C ${90 + wingTier * 6} ${35 - wingTier * 4}, ${110 + wingTier * 4} ${58 - wingTier * 2}, 98 74 C 86 66, 74 60, 60 60 Z`} fill={`url(#wing-${gid})`} opacity="0.85" />
              </>
            )}
            {/* asas principais */}
            <path d={`M58 52 C ${34 - wingTier * 4} ${40 - wingTier * 3}, ${14 - wingTier * 3} ${50 - wingTier * 2}, 16 70 C 30 62, 44 56, 58 58 Z`} fill={`url(#wing-${gid})`} stroke={colorTheme.dark} strokeWidth="1" />
            <path d={`M62 52 C ${86 + wingTier * 4} ${40 - wingTier * 3}, ${106 + wingTier * 3} ${50 - wingTier * 2}, 104 70 C 90 62, 76 56, 62 58 Z`} fill={`url(#wing-${gid})`} stroke={colorTheme.dark} strokeWidth="1" />
            <path d="M16 70 L23 64 M20 72 L28 68 M24 74 L33 71" stroke={colorTheme.dark} strokeWidth="1" opacity="0.6" />
            <path d="M104 70 L97 64 M100 72 L92 68 M96 74 L87 71" stroke={colorTheme.dark} strokeWidth="1" opacity="0.6" />

            {/* cauda */}
            <path d="M60 92 C 66 100, 78 104, 88 108 C 82 102, 92 104, 96 110" fill="none" stroke={colorTheme.hex} strokeWidth="6" strokeLinecap="round" />
            <path d="M96 110 L102 106 L100 114 Z" fill={colorTheme.light} />

            {/* corpo */}
            <ellipse cx="60" cy="76" rx="20" ry="24" fill={`url(#body-${gid})`} />
            {/* barriga */}
            <ellipse cx="60" cy="82" rx="10" ry="14" fill={colorTheme.dark} opacity="0.55" />

            {/* cabeça */}
            <ellipse cx="60" cy="42" rx="17" ry="15" fill={`url(#body-${gid})`} stroke={colorTheme.dark} strokeWidth="1.4" />
            {/* focinho */}
            <path d="M48 44 Q40 46 40 52 Q46 52 52 48 Z" fill={colorTheme.hex} stroke={colorTheme.dark} strokeWidth="1" />

            {/* chifres — mais e maiores em estágios avançados */}
            <path d="M50 30 L46 16 L54 28 Z" fill={colorTheme.light} />
            <path d="M70 30 L74 16 L66 28 Z" fill={colorTheme.light} />
            {wingTier >= 2 && (
              <>
                <path d="M56 26 L54 12 L60 24 Z" fill={colorTheme.light} opacity="0.9" />
                <path d="M64 26 L66 12 L60 24 Z" fill={colorTheme.light} opacity="0.9" />
              </>
            )}

            {/* espinhos no dorso */}
            <path d="M52 30 L50 22 L56 28 M60 28 L60 18 L64 28 M68 30 L70 22 L64 28" fill={colorTheme.light} opacity="0.8" />
            {[...Array(wingTier + 1)].map((_, i) => (
              <path key={i} d={`M${58 - i * 2} ${60 + i * 6} L${55 - i * 2} ${54 + i * 6} L${62 - i * 2} ${58 + i * 6} Z`} fill={colorTheme.light} opacity="0.7" />
            ))}

            {/* olhos brilhantes */}
            <circle cx="53" cy="40" r="2.6" fill={colorTheme.eye} />
            <circle cx="67" cy="40" r="2.6" fill={colorTheme.eye} />
            <circle cx="53" cy="40" r="5" fill={colorTheme.eye} opacity="0.35" />
            <circle cx="67" cy="40" r="5" fill={colorTheme.eye} opacity="0.35" />

            {/* fogo/aura na boca em estágios avançados */}
            {dragonEvolution.min >= 21 && (
              <path d="M60 50 Q56 56 60 60 Q64 56 60 50 Z" fill={colorTheme.eye} opacity="0.8" />
            )}
          </>
        )}
      </svg>
    </div>
  );
}


/* =========================================================
   SMALL UI PIECES
   ========================================================= */
function Bar({ value, max, color }) {
  const pct = Math.max(0, Math.min(100, (value / max) * 100));
  return (
    <div className="w-full bg-stone-800 rounded-full h-2">
      <div className={`${color} h-2 rounded-full transition-all duration-500`} style={{ width: `${pct}%` }} />
    </div>
  );
}

function Stat({ label, value, color }) {
  return (
    <div>
      <div className={`font-bold ${color}`}>{value}</div>
      <div className="text-[9px] text-stone-500">{label}</div>
    </div>
  );
}

function ShopRow({ icon, name, detail, cost, owned, disabled, onBuy, buyLabel = "Comprar" }) {
  return (
    <div className="bg-stone-950 rounded-xl p-3 border border-stone-800 flex items-center justify-between">
      <div className="flex items-center gap-3">
        <div className="text-2xl">{icon}</div>
        <div><div className="text-sm font-medium">{name}</div><div className="text-[11px] text-stone-500">{detail}</div></div>
      </div>
      {owned ? (
        <span className="text-xs text-emerald-500 font-medium px-3">Adquirido</span>
      ) : (
        <button onClick={onBuy} disabled={disabled} className={`text-xs font-semibold px-3 py-1.5 rounded-lg flex items-center gap-1 transition-colors ${disabled ? "bg-stone-800 text-stone-600 cursor-not-allowed" : "bg-red-800 hover:bg-red-700 text-white"}`}>
          <Coins className="w-3 h-3" /> {cost.toLocaleString("pt-BR")}
        </button>
      )}
    </div>
  );
}
