import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";

export default defineConfig({
  plugins: [react()],
  // Se for publicar no GitHub Pages em https://usuario.github.io/nome-do-repo/,
  // troque "/" pelo nome do repositório: base: "/nome-do-repo/"
  base: "/",
});
